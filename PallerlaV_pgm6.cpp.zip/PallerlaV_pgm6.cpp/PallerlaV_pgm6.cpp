/*Vishi Pallerla, CS 2010, 3:30p - 4:20p
* Program 6, PallerlaV_pgm6.cpp, 11/19/21
* 
* Purpose: Take a file of Air Force pilots and select the qualified candidates based on their standing height,
* siiting height, and age.
* 
* Input: Take in a file called AFSelection.txt that has the Air Force pilot data. Put that data into parallel arrays,
* of standing height, sitting height, and age.
* 
* Processing: Take in data from AFSelection.txt and put into arrays. Print out the data. Then convert the standing
* and siiting heights from centimeters to inches. Display the new data. Find and display the average standing height,
* sitting height, and age. Finally, find and display the qualified candidates. The qualifiers are: standing height
* between 64 and 77 inches, sitting height between 34 and 40 inches, and age between  28 and 33 years old.
* 
* Output: Display the original data, the data after centimeters are converted to inches, the averages of each array,
* and the qualified candidates' data.
*/

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

//This function displays the data from the file for the user.
void DisplayData(double standHeight[], double sitHeight[], double age[], int num) {
	//for formatting
	cout << fixed << setprecision(2);
	//display header
	cout << "Candidate_Number  StandH     SitH      Age" << endl;
	cout << "--------------------------------------------" << endl;
	for (int i = 0; i < num; ++i) {
		//prints out data
		cout << left << setw(16) << i + 1 << "  ";
		cout << setw(6) << standHeight[i] << "     ";
		cout << setw(6) << sitHeight[i] << "    ";
		cout << setw(3) << age[i] << endl;
	}
}

//Converts the data in the standing height array and sitting height array from centimeters to inches.
void ConvertCmToIn(double standHeight[], double sitHeight[], int num) {
	for (int i = 0; i < num; ++i) {
		//converts centimeters to inches
		standHeight[i] = standHeight[i] / 2.54;
		sitHeight[i] = sitHeight[i] / 2.54;
	}
}

//Adds up all the numbers in the array and divides by the number of elements to get the average.
double Average(double arr[], int num) {
	double total = 0.0;

	for (int i = 0; i < num; ++i) {
		//gets total of all elements in array
		total += arr[i];
	}

	//return average
	return total / num;
}

//Finds and displays the qualified candidates.
void Qualified(double standHeight[], double sitHeight[], double age[], int num) {
	//number of qualified candidates
	int numQ = 0;
	//for conditions
	bool standQ;
	bool sitQ;
	bool ageQ;
	//array, stores the index of qualified candidates
	int arrQ[50];

	//finds qualified candidates and stores their index in arrQ
	for (int i = 0; i < num; ++i) {
		//conditions
		standQ = standHeight[i] >= 64 && standHeight[i] <= 77;
		sitQ = sitHeight[i] >= 34 && sitHeight[i] <= 40;
		ageQ = age[i] >= 18 && age[i] <= 33;
		//stores qualfied index, -1 if not
		if (standQ && sitQ && ageQ) {
			arrQ[i] = i;
			++numQ;
		}
		else {
			arrQ[i] = -1;
		}
	}

	//prints out qualified candidates
	
	//prints number of qualified candidates
	cout << numQ << " candidates are qualified." << endl;
	//output formatting
	cout << fixed << setprecision(2);
	//display header
	cout << "Candidate_Number  StandH     SitH      Age" << endl;
	cout << "--------------------------------------------" << endl;
	for (int j = 0; j < num; ++j) {
		if (arrQ[j] != -1) {
			//prints out qualified data
			cout << left << setw(16) << j + 1 << "  ";
			cout << setw(6) << standHeight[arrQ[j]] << "     ";
			cout << setw(6) << sitHeight[arrQ[j]] << "    ";
			cout << setw(3) << age[arrQ[j]] << endl;
		}
	}
}

int main() {
	//for input file
	ifstream inFile;
	//number of elements
	const int NUM = 50;
	//arrays
	double standHeight[NUM];
	double sitHeight[NUM];
	double age[NUM];
	//for loops
	int i = 0;
	//number of elements
	int numE = 0;
	//averages
	double standAvg;
	double sitAvg;
	double ageAvg;

	//opens AFSelection.txt file
	inFile.open("AFSelection.txt");
	if (!inFile.is_open())
	{
		cout << "Could not open AFSelection.txt file" << endl;
		return 1;
	}	

	//loop to input data from file into arrays
	while (!inFile.eof())
	{
		//inputs
		inFile >> standHeight[i];
		inFile >> sitHeight[i];
		inFile >> age[i];
		//keeps track of number of variables
		++i;
	}
	//have to subtract 1 from i because it added an extra value at the end of the loop
	numE = i - 1;
	//start of output
	cout << "Reached the end of of the file!" << endl;
	cout << "--------------------------------------------" << endl;
	cout << "--------------------------------------------" << endl;

	//calls function to display original data
	cout << "\nOriginal Data:" << endl;
	DisplayData(standHeight, sitHeight, age, numE);

	//calls function to convert centimeters to inches for heights
	ConvertCmToIn(standHeight, sitHeight, numE);
	//calls function to display new data
	cout << "\nConverted Data (cm to in):" << endl;
	DisplayData(standHeight, sitHeight, age, numE);

	//calls function to get averages of each array
	standAvg =  Average(standHeight, numE);
	sitAvg = Average(sitHeight, numE);
	ageAvg = Average(age, numE);

	//displays averages
	cout << fixed << setprecision(2);
	cout << "\nAverages:" << endl;
	cout << "StandH     SitH      Age" << endl;
	cout << "--------------------------" << endl;
	cout << setw(6) << standAvg << "     ";
	cout << setw(6) << sitAvg << "    ";
	cout << setw(6) << ageAvg << endl;

	//calls function to get qualified candidates
	cout << "\nQualified Candidates:" << endl;
	Qualified(standHeight, sitHeight, age, numE);

	//closes file
	inFile.close();

	return 0;
}